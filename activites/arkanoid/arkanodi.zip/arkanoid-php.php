// save_game.php - Sauvegarde de l'état du jeu

<?php
// Pseudocode - Fonction pour sauvegarder l'état du jeu

/**
 * Récupération et sauvegarde de l'état du jeu
 */
function sauvegarderEtatJeu() {
    // Récupération de l'ID utilisateur depuis la session
    $user_id = $_SESSION['user_id'] ?? 'invité';
    
    // Récupération des données JSON envoyées par le client
    $json_data = file_get_contents('php://input');
    
    // Décodage des données JSON
    $game_state = json_decode($json_data, true);
    
    // Vérification que les données sont valides
    if (!$game_state || !isset($game_state['score'])) {
        // Retourner une erreur si les données sont invalides
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Données de jeu invalides']);
        exit;
    }
    
    // Créer un fichier de sauvegarde unique pour cet utilisateur
    $save_file = 'saves/' . $user_id . '_arkanoid_save.json';
    
    // Ajouter un timestamp à la sauvegarde
    $game_state['saved_at'] = time();
    
    // Création du répertoire de sauvegarde s'il n'existe pas
    if (!is_dir('saves')) {
        mkdir('saves', 0755, true);
    }
    
    // Écriture des données dans le fichier
    if (file_put_contents($save_file, json_encode($game_state))) {
        // Succès - Retourner un message de confirmation
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Jeu sauvegardé avec succès']);
    } else {
        // Échec - Retourner une erreur
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(['error' => 'Erreur lors de la sauvegarde du jeu']);
    }
}

// Vérification que la requête est de type POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    sauvegarderEtatJeu();
} else {
    // Si la méthode n'est pas POST, retourner une erreur
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['error' => 'Méthode non autorisée']);
}
?>

// load_game.php - Chargement de l'état du jeu

<?php
// Pseudocode - Fonction pour charger l'état du jeu sauvegardé

/**
 * Récupération de l'état du jeu sauvegardé
 */
function chargerEtatJeu() {
    // Récupération de l'ID utilisateur depuis la session
    $user_id = $_SESSION['user_id'] ?? 'invité';
    
    // Déterminer le chemin du fichier de sauvegarde
    $save_file = 'saves/' . $user_id . '_arkanoid_save.json';
    
    // Vérifier si le fichier existe
    if (!file_exists($save_file)) {
        // Si aucune sauvegarde n'existe, retourner une erreur
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'Aucune sauvegarde trouvée']);
        exit;
    }
    
    // Lire le contenu du fichier
    $json_data = file_get_contents($save_file);
    
    // Vérifier que les données sont valides
    $game_state = json_decode($json_data, true);
    if (!$game_state || !isset($game_state['score'])) {
        // Retourner une erreur si les données sont corrompues
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(['error' => 'Données de sauvegarde corrompues']);
        exit;
    }
    
    // Ajouter des informations sur la sauvegarde
    $game_state['loaded_at'] = time();
    if (isset($game_state['saved_at'])) {
        $game_state['save_age'] = $game_state['loaded_at'] - $game_state['saved_at'];
    }
    
    // Retourner les données de sauvegarde
    header('Content-Type: application/json');
    echo json_encode($game_state);
}

// Vérification que la requête est de type GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    chargerEtatJeu();
} else {
    // Si la méthode n'est pas GET, retourner une erreur
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['error' => 'Méthode non autorisée']);
}
?>

// Pseudocode pour la gestion des sessions des utilisateurs (optionnel)

<?php
// session_manager.php

// Démarrage de la session
session_start();

// Fonction pour créer une nouvelle session utilisateur
function createUserSession($user_id) {
    $_SESSION['user_id'] = $user_id;
    $_SESSION['created_at'] = time();
    
    // Générer un identifiant unique pour cette session
    $_SESSION['session_id'] = uniqid('arkanoid_', true);
    
    return true;
}

// Fonction pour vérifier si l'utilisateur est connecté
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Fonction pour déconnecter l'utilisateur
function logoutUser() {
    // Détruire la session
    session_destroy();
    
    // Supprimer le cookie de session
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    return true;
}

// Fonction pour récupérer les sauvegardes d'un utilisateur
function getUserSaves($user_id) {
    $saves_dir = 'saves/';
    $pattern = $saves_dir . $user_id . '_*.json';
    
    $save_files = glob($pattern);
    $saves = [];
    
    foreach ($save_files as $file) {
        $json_data = file_get_contents($file);
        $save_data = json_decode($json_data, true);
        
        if ($save_data) {
            $saves[] = [
                'file' => basename($file),
                'saved_at' => $save_data['saved_at'] ?? 0,
                'score' => $save_data['score'] ?? 0
            ];
        }
    }
    
    // Trier les sauvegardes par date (la plus récente en premier)
    usort($saves, function($a, $b) {
        return $b['saved_at'] - $a['saved_at'];
    });
    
    return $saves;
}
?>
