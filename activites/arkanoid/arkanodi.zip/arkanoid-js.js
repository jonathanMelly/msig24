// Variables globales
let gameState = {
    score: 0,
    ballPos: { x: 240, y: 400 },
    ballVelocity: { x: 2, y: -4 },
    paddlePos: { x: 190, y: 620 },
    bricks: [],
    gameRunning: false,
    gamePaused: false,
    lives: 3
};

// Éléments DOM
const gameContainer = document.getElementById('game-container');
const paddle = document.getElementById('paddle');
const ball = document.getElementById('ball');
const scoreValue = document.getElementById('score-value');
const startBtn = document.getElementById('start-btn');
const pauseBtn = document.getElementById('pause-btn');
const saveBtn = document.getElementById('save-btn');
const loadBtn = document.getElementById('load-btn');

// Dimensions et paramètres
const paddleWidth = 100;
const paddleHeight = 20;
const ballSize = 15;
const brickWidth = 60;
const brickHeight = 20;
const brickGap = 10;
const containerWidth = 480;
const containerHeight = 640;

// Initialisation du jeu
function initGame() {
    // Réinitialisation du score
    gameState.score = 0;
    scoreValue.textContent = gameState.score;
    
    // Réinitialisation de la position de la balle
    gameState.ballPos = { x: containerWidth / 2, y: containerHeight / 2 };
    
    // Réinitialisation de la vitesse de la balle
    gameState.ballVelocity = { x: 2, y: -4 };
    
    // Réinitialisation de la position de la raquette
    gameState.paddlePos = { x: (containerWidth - paddleWidth) / 2, y: containerHeight - paddleHeight - 20 };
    
    // Création des briques
    createBricks();
    
    // Rendu initial
    render();
}

// Création des briques
function createBricks() {
    // Vider le tableau des briques actuelles
    gameState.bricks = [];
    
    // Paramètres pour la grille de briques
    const rows = 5;
    const cols = 7;
    const topOffset = 50;
    
    // Génération des briques
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            gameState.bricks.push({
                x: col * (brickWidth + brickGap) + brickGap,
                y: row * (brickHeight + brickGap) + topOffset,
                width: brickWidth,
                height: brickHeight,
                destroyed: false,
                color: getRandomColor()
            });
        }
    }
}

// Rendu du jeu
function render() {
    // Mise à jour du score
    scoreValue.textContent = gameState.score;
    
    // Position de la balle
    ball.style.left = gameState.ballPos.x + 'px';
    ball.style.top = gameState.ballPos.y + 'px';
    
    // Position de la raquette
    paddle.style.left = gameState.paddlePos.x + 'px';
    paddle.style.top = gameState.paddlePos.y + 'px';
    
    // Supprimer toutes les briques existantes dans le DOM
    const existingBricks = document.querySelectorAll('.brick');
    existingBricks.forEach(brick => brick.remove());
    
    // Rendu des briques
    gameState.bricks.forEach((brick, index) => {
        if (!brick.destroyed) {
            const brickElement = document.createElement('div');
            brickElement.className = 'brick';
            brickElement.style.left = brick.x + 'px';
            brickElement.style.top = brick.y + 'px';
            brickElement.style.backgroundColor = brick.color;
            brickElement.dataset.index = index;
            gameContainer.appendChild(brickElement);
        }
    });
}

// Mise à jour du jeu
function update() {
    if (!gameState.gameRunning || gameState.gamePaused) return;
    
    // Déplacement de la balle
    gameState.ballPos.x += gameState.ballVelocity.x;
    gameState.ballPos.y += gameState.ballVelocity.y;
    
    // Détection des collisions avec les bords
    // Bord gauche et droit
    if (gameState.ballPos.x <= 0 || gameState.ballPos.x >= containerWidth - ballSize) {
        gameState.ballVelocity.x = -gameState.ballVelocity.x;
    }
    
    // Bord supérieur
    if (gameState.ballPos.y <= 0) {
        gameState.ballVelocity.y = -gameState.ballVelocity.y;
    }
    
    // Bord inférieur (game over)
    if (gameState.ballPos.y >= containerHeight - ballSize) {
        gameState.lives--;
        if (gameState.lives <= 0) {
            resetBall();
            gameState.gameRunning = false;
            alert("Game Over! Score final: " + gameState.score);
        } else {
            resetBall();
        }
    }
    
    // Collision avec la raquette
    if (
        gameState.ballPos.y + ballSize >= gameState.paddlePos.y &&
        gameState.ballPos.y <= gameState.paddlePos.y + paddleHeight &&
        gameState.ballPos.x + ballSize >= gameState.paddlePos.x &&
        gameState.ballPos.x <= gameState.paddlePos.x + paddleWidth
    ) {
        // Calcul d'un angle de rebond basé sur l'endroit où la balle touche la raquette
        const hitPosition = (gameState.ballPos.x - gameState.paddlePos.x) / paddleWidth;
        const angle = (hitPosition - 0.5) * Math.PI; // Entre -π/2 et π/2
        
        gameState.ballVelocity.y = -Math.abs(gameState.ballVelocity.y);
        gameState.ballVelocity.x = Math.sin(angle) * 5;
    }
    
    // Collision avec les briques
    for (let i = 0; i < gameState.bricks.length; i++) {
        const brick = gameState.bricks[i];
        if (!brick.destroyed) {
            if (
                gameState.ballPos.y <= brick.y + brickHeight &&
                gameState.ballPos.y + ballSize >= brick.y &&
                gameState.ballPos.x <= brick.x + brickWidth &&
                gameState.ballPos.x + ballSize >= brick.x
            ) {
                brick.destroyed = true;
                gameState.score += 10;
                
                // Rebondissement (simplifié)
                gameState.ballVelocity.y = -gameState.ballVelocity.y;
                
                // Vérification si toutes les briques sont détruites
                if (gameState.bricks.every(brick => brick.destroyed)) {
                    gameState.gameRunning = false;
                    alert("Félicitations ! Vous avez gagné avec un score de " + gameState.score);
                }
                
                break;
            }
        }
    }
    
    render();
}

// Réinitialisation de la balle
function resetBall() {
    gameState.ballPos = { x: containerWidth / 2, y: containerHeight / 2 };
    gameState.ballVelocity = { x: 2, y: -4 };
}

// Génération d'une couleur aléatoire
function getRandomColor() {
    const colors = ['#4ecca3', '#e94560', '#ffbd69', '#61dafb', '#845ec2'];
    return colors[Math.floor(Math.random() * colors.length)];
}

// Gestionnaire d'événements pour le mouvement de la souris
function handleMouseMove(e) {
    if (!gameState.gameRunning || gameState.gamePaused) return;
    
    const gameRect = gameContainer.getBoundingClientRect();
    const mouseX = e.clientX - gameRect.left;
    
    // Limiter la position de la raquette aux bords du conteneur
    if (mouseX >= paddleWidth / 2 && mouseX <= containerWidth - paddleWidth / 2) {
        gameState.paddlePos.x = mouseX - paddleWidth / 2;
    }
    
    render();
}

// Gestionnaire d'événements pour le bouton Start
function handleStart() {
    if (!gameState.gameRunning) {
        gameState.gameRunning = true;
        gameState.lives = 3;
        initGame();
        gameLoop();
    }
}

// Gestionnaire d'événements pour le bouton Pause
function handlePause() {
    gameState.gamePaused = !gameState.gamePaused;
    pauseBtn.textContent = gameState.gamePaused ? 'Reprendre' : 'Pause';
}

// Gestionnaire d'événements pour le bouton Save
function handleSave() {
    // Envoyer l'état du jeu au serveur via AJAX
    const gameStateJSON = JSON.stringify(gameState);
    
    // Créer une requête AJAX (ici simplement montré comme pseudocode)
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_game.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert('Partie sauvegardée avec succès !');
        }
    };
    xhr.send(gameStateJSON);
}

// Gestionnaire d'événements pour le bouton Load
function handleLoad() {
    // Charger l'état du jeu depuis le serveur via AJAX
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'load_game.php', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                const loadedState = JSON.parse(xhr.responseText);
                gameState = loadedState;
                render();
                
                if (!gameState.gamePaused) {
                    gameState.gameRunning = true;
                    gameLoop();
                }
                
                alert('Partie chargée avec succès !');
            } catch (e) {
                alert('Erreur lors du chargement de la partie.');
            }
        }
    };
    xhr.send();
}

// Boucle de jeu principale
function gameLoop() {
    update();
    if (gameState.gameRunning) {
        requestAnimationFrame(gameLoop);
    }
}

// Ajout des gestionnaires d'événements
gameContainer.addEventListener('mousemove', handleMouseMove);
startBtn.addEventListener('click', handleStart);
pauseBtn.addEventListener('click', handlePause);
saveBtn.addEventListener('click', handleSave);
loadBtn.addEventListener('click', handleLoad);

// Initialisation du jeu au chargement
document.addEventListener('DOMContentLoaded', initGame);
