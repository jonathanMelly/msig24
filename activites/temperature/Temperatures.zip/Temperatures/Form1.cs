using System;

namespace Temperatures
{
    public partial class Form1 : Form
    {
        List<int> temperatures = new();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            var g = graph.CreateGraphics();
            //Axes
            g.FillRectangle(Brushes.Black,0, graph.Height-1,graph.Width, 1);
            g.FillRectangle(Brushes.Black, 0, 0, 1, graph.Height);

            int i = 0;
            const int size = 10;
            //Temps
            foreach (int temp in temperatures)
            {
                g.FillRectangle(Brushes.Red, size*i++, graph.Height-size - temp, size, size);
            }
            
        }

        private void btnImport_Click(object sender, EventArgs e)
        {


            temperatures = File.ReadAllLines("data.txt")
                .Select(temperatureStr=>Convert.ToInt32(temperatureStr)).ToList();

            MessageBox.Show($"Imported {temperatures.Count} temps");


        }
    }
}
