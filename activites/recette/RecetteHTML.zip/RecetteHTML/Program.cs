﻿//Auteur : JMY
//Date   : 02.11.2021 
//Lieu   : ETML
//Descr. : Affiche une recette en image
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace RecetteHTML
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ingrédients de la recette
            var brownies = new List<string>{"farine","oeuf","chocolat","noix","sucre"};
            var browniesDescription = "brownies.html";

            //Crée un fichier pour y écrire du HTML
            var html = File.CreateText(browniesDescription);

            //Écriture de l’entête HTML
            html.WriteLine("<html>");

            //Nom de la recette
            html.WriteLine("<h1>BROWNIES</h1>");

            //On ajoute une image pour chaque ingrédient au format HTML
            foreach (var ingredient in brownies)
            {
                html.WriteLine("<img src=\"../../../images/{0}.jpg\" />",ingredient);
            }

            //Écriture de la fin de HTML
            html.WriteLine("</html>");

            //Fermeture du fichier
            html.Close();

            //Affiche la recette sur le navigateur
            Process.Start("explorer",browniesDescription);
        }
    }
}
