﻿namespace Destiny
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            lblCarsCount = new Label();
            button2 = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MV Boli", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(51, 57);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(76, 37);
            label1.TabIndex = 0;
            label1.Text = "Cars";
            // 
            // button1
            // 
            button1.Font = new Font("MV Boli", 14F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(49, 110);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(249, 42);
            button1.TabIndex = 1;
            button1.Text = "Add car";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblCarsCount
            // 
            lblCarsCount.AutoSize = true;
            lblCarsCount.Font = new Font("MV Boli", 14F, FontStyle.Bold, GraphicsUnit.Point);
            lblCarsCount.Location = new Point(184, 57);
            lblCarsCount.Margin = new Padding(4, 0, 4, 0);
            lblCarsCount.Name = "lblCarsCount";
            lblCarsCount.Size = new Size(38, 37);
            lblCarsCount.TabIndex = 2;
            lblCarsCount.Text = "0";
            // 
            // button2
            // 
            button2.Location = new Point(57, 246);
            button2.Name = "button2";
            button2.Size = new Size(235, 47);
            button2.TabIndex = 3;
            button2.Text = "Random ?";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(298, 257);
            label2.Name = "label2";
            label2.Size = new Size(75, 25);
            label2.TabIndex = 4;
            label2.Text = "random";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1143, 750);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(lblCarsCount);
            Controls.Add(button1);
            Controls.Add(label1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Label lblCarsCount;
        private Button button2;
        private Label label2;
    }
}
