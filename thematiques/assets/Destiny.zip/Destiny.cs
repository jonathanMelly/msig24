﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Destiny
{
    public class Destiny
    {
        static int number=0;

        static public int Next(int max) 
        { 
            return number++; 
        }
    }
}
