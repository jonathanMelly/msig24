﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Destiny
{
    public class Car
    {
        static public int Counter = 0;
        public string Name;
        public int GetCounter()
        {
            return Counter;
        }

        public Car(string name) 
        {
            Name = name;
            Counter = Counter + 1;
        }

    }
}
