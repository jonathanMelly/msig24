using Microsoft.VisualBasic;

namespace Destiny
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var carName = Interaction.InputBox("car name");
            if (carName != null)
            {
                Car car = new Car(carName);
                lblCarsCount.Text = Car.Counter/* car.GetCounter()*/ + "";
            }
        }

        List<int> numbers = new List<int>();

        static Random random = new Random();
        private void button2_Click(object sender, EventArgs e)
        {
            //for(int i=0; i<100; i++)
            {
                
                numbers.Add(Destiny.Next(100));
            }
            
            label2.Text = numbers.Average().ToString();
        }
    }
}
