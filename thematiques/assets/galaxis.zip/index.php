<?php
session_start();//to generate fake userid

require('db.php');

// Handle add to cart action
if (isset($_POST['add_to_cart']) && isset($_POST['product_id'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    $user_id = session_id(); // Using session_id as user identifier
    
    try {
        // Check if product already in cart
        $stmt = $pdo->prepare("SELECT id, quantity FROM cart_items WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        $existing_item = $stmt->fetch();
        
        if ($existing_item) {
            // Update quantity if product exists
            $stmt = $pdo->prepare("UPDATE cart_items SET quantity = quantity + ? WHERE id = ?");
            $stmt->execute([$quantity, $existing_item['id']]);
        } else {
            // Insert new cart item
            $stmt = $pdo->prepare("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$user_id, $product_id, $quantity]);
        }
        
        header('Location: cart.php');
        exit;
    } catch (PDOException $e) {
        echo "Error handling cart: " . $e->getMessage();
    }
}

// Update product views
if (isset($_GET['product_id'])) {
    try {
        $stmt = $pdo->prepare("UPDATE products SET views = views + 1 WHERE id = ?");
        $stmt->execute([$_GET['product_id']]);
    } catch (PDOException $e) {
        echo "Error updating views: " . $e->getMessage();
    }
}

// Get sorting parameter
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'price_asc';
$sort_sql = "ORDER BY current_price ASC"; // default sorting

switch($sort) {
    case 'price_desc':
        $sort_sql = "ORDER BY current_price DESC";
        break;
    case 'name':
        $sort_sql = "ORDER BY p.name ASC";
        break;
    case 'views':
        $sort_sql = "ORDER BY p.views DESC";
        break;
}

// Fetch products with current prices
try {
    $products_query = "
        SELECT p.*, 
            (SELECT price 
             FROM product_prices pp 
             WHERE pp.product_id = p.id 
             AND pp.start_date <= CURRENT_DATE 
             ORDER BY start_date DESC 
             LIMIT 1) as current_price
        FROM products p
        " . $sort_sql;
    
    $products = $pdo->query($products_query);
    
    // Fetch statistics
    $stats_query = "
        SELECT 
            (SELECT name FROM products ORDER BY views DESC LIMIT 1) as most_viewed,
            (SELECT p.name 
             FROM products p 
             JOIN product_prices pp ON p.id = pp.product_id 
             WHERE pp.start_date <= CURRENT_DATE 
             ORDER BY pp.price DESC LIMIT 1) as most_expensive,
            (SELECT p.name 
             FROM products p 
             JOIN product_prices pp ON p.id = pp.product_id 
             WHERE pp.start_date <= CURRENT_DATE 
             ORDER BY pp.price ASC LIMIT 1) as least_expensive,
            (SELECT AVG(price) 
             FROM product_prices 
             WHERE start_date <= CURRENT_DATE) as avg_price
    ";
    
    $stats = $pdo->query($stats_query);
    $statistics = $stats->fetch();
} catch (PDOException $e) {
    echo "Error fetching data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>WebShop</title>
    <style>
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .product-image {
            max-width: 200px;
            height: auto;
        }
        .statistics {
            background: #f5f5f5;
            padding: 15px;
            margin: 20px;
        }
        .cart-count {
            background: #ff4444;
            color: white;
            padding: 2px 6px;
            border-radius: 50%;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>WebShop</h1>
        <nav>
            <?php
            // Get cart count
            $stmt = $pdo->prepare("SELECT SUM(quantity) as count FROM cart_items WHERE user_id = ?");
            $stmt->execute([session_id()]);
            $cart_count = $stmt->fetch()['count'] ?? 0;
            ?>
            <a href="cart.php">Voir le panier<?php if($cart_count > 0): ?>
                <span class="cart-count"><?php echo $cart_count; ?></span>
            <?php endif; ?></a>
            <div>
                Trier par:
                <a href="?sort=price_asc">Prix croissant</a> |
                <a href="?sort=price_desc">Prix décroissant</a> |
                <a href="?sort=name">Nom</a> |
                <a href="?sort=views">Plus consultés</a>
            </div>
        </nav>
    </header>

    <div class="statistics">
        <h3>Statistiques</h3>
        <p>Produit le plus consulté: <?php echo htmlspecialchars($statistics['most_viewed']); ?></p>
        <p>Produit le plus cher: <?php echo htmlspecialchars($statistics['most_expensive']); ?></p>
        <p>Produit le moins cher: <?php echo htmlspecialchars($statistics['least_expensive']); ?></p>
        <p>Prix moyen: <?php echo number_format($statistics['avg_price'], 2); ?> CHF</p>
    </div>

    <div class="product-grid">
    <?php while($product = $products->fetch()): ?>
        <div class="product-card">
            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                 class="product-image">
            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
            <p><?php echo htmlspecialchars($product['description']); ?></p>
            <p>Prix: <?php echo number_format($product['current_price'], 2); ?> CHF</p>
            <form method="post" action="">
                <input type="hidden" name="product_id" 
                       value="<?php echo $product['id']; ?>">
                <input type="number" name="quantity" value="1" min="1">
                <button type="submit" name="add_to_cart">Ajouter au panier</button>
            </form>
        </div>
    <?php endwhile; ?>
    </div>
</body>
</html>

