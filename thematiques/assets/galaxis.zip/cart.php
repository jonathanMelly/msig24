<?php
session_start();//to fake userid
require('db.php');


// Update quantities
if (isset($_POST['update_cart'])) {
    try {
        foreach ($_POST['quantity'] as $item_id => $quantity) {
            if ($quantity > 0) {
                $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$quantity, $item_id, session_id()]);
            } else {
                $stmt = $pdo->prepare("DELETE FROM cart_items WHERE id = ? AND user_id = ?");
                $stmt->execute([$item_id, session_id()]);
            }
        }
    } catch (PDOException $e) {
        echo "Error updating cart: " . $e->getMessage();
    }
}

// Fetch cart items
try {
    $cart_query = "
        SELECT ci.id, ci.quantity, p.name, p.image_url,
               (SELECT price 
                FROM product_prices pp 
                WHERE pp.product_id = p.id 
                AND pp.start_date <= CURRENT_DATE 
                ORDER BY start_date DESC 
                LIMIT 1) as price
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ?
        ORDER BY p.name
    ";
    
    $stmt = $pdo->prepare($cart_query);
    $stmt->execute([session_id()]);
    $cart_items = $stmt->fetchAll();
    
    $total = 0;
} catch (PDOException $e) {
    echo "Error fetching cart: " . $e->getMessage();
    $cart_items = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Panier - WebShop</title>
    <style>
        .cart-table { width: 100%; border-collapse: collapse; }
        .cart-table th, .cart-table td { padding: 10px; border: 1px solid #ddd; }
        .cart-image { max-width: 100px; }
        .payment-form { max-width: 500px; margin: 20px auto; padding: 20px; }
        .payment-form input { width: 100%; margin: 10px 0; padding: 5px; }
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>
    <h1>Votre panier</h1>
    <a href="index.php">← Retour à la boutique</a>

    <?php if (empty($cart_items)): ?>
        <p>Votre panier est vide.</p>
    <?php else: ?>
    <form method="post">
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Produit</th>
                    <th>Prix unitaire</th>
                    <th>Quantité</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($cart_items as $item): 
                    $item_total = $item['price'] * $item['quantity'];
                    $total += $item_total;
                ?>
                <tr>
                    <td>
                        <img src="<?php echo htmlspecialchars($item['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($item['name']); ?>" 
                             class="cart-image">
                        <?php echo htmlspecialchars($item['name']); ?>
                    </td>
                    <td><?php echo number_format($item['price'], 2); ?> CHF</td>
                    <td>
                        <input type="number" name="quantity[<?php echo $item['id']; ?>]" 
                               value="<?php echo $item['quantity']; ?>" min="0">
                    </td>
                    <td><?php echo number_format($item_total, 2); ?> CHF</td>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="3"><strong>Total</strong></td>
                    <td><strong><?php echo number_format($total, 2); ?> CHF</strong></td>
                </tr>
            </tbody>
        </table>
        <button type="submit" name="update_cart">Mettre à jour le panier</button>
    </form>

    <div class="payment-form">
        <h2>Paiement</h2>
        <form method="post" action="process_payment.php" id="payment-form">
            <input type="text" name="card_number" placeholder="Numéro de carte" required 
                   pattern="\d{16}" title="Entrez les 16 chiffres de votre carte"
                   oninput="this.value = this.value.replace(/[^\d]/g, '').substr(0, 16)">
            
            <input type="text" name="card_holder" placeholder="Nom du titulaire" required>
            
            <input type="text" name="expiry" placeholder="MM/YY" required 
                   pattern="(0[1-9]|1[0-2])\/([0-9]{2})"
                   oninput="this.value = this.value.replace(/[^\d/]/g, '').substr(0, 5)"
                   onkeyup="if(this.value.length === 2 && !this.value.includes('/')) this.value += '/'">
            
            <input type="text" name="cvv" placeholder="CVV" required
                   pattern="\d{3}" title="Entrez les 3 chiffres au dos de votre carte"
                   oninput="this.value = this.value.replace(/[^\d]/g, '').substr(0, 3)">
            
            <input type="hidden" name="total" value="<?php echo $total; ?>">
            <button type="submit">Payer <?php echo number_format($total, 2); ?> CHF</button>
        </form>
    </div>
    <?php endif; ?>

    <script>
        document.getElementById('payment-form').onsubmit = function(e) {
            e.preventDefault();
            alert('Paiement simulé - Dans un environnement réel, ceci serait connecté à un processeur de paiement.');
            window.location.href = 'index.php';
        };
    </script>
</body>
</html>
