-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           10.6.5-MariaDB-log - mariadb.org binary distribution
-- SE du serveur:                Win64
-- HeidiSQL Version:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Listage de la structure de table webshop. cart_items
CREATE TABLE IF NOT EXISTS `cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_cart_item` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `cart_items_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Listage des données de la table webshop.cart_items : ~8 rows (environ)
INSERT INTO `cart_items` (`id`, `user_id`, `product_id`, `quantity`, `date_added`) VALUES
	(1, 'sample_session_1', 1, 1, '2025-01-14 07:33:01'),
	(2, 'sample_session_1', 6, 2, '2025-01-14 07:33:01'),
	(3, 'sample_session_2', 12, 1, '2025-01-14 07:33:01'),
	(4, 'sample_session_2', 13, 2, '2025-01-14 07:33:01'),
	(5, 'sample_session_3', 19, 1, '2025-01-14 07:33:01'),
	(6, '', 19, 2, '2025-01-14 07:37:16'),
	(7, '', 14, 1, '2025-01-14 07:37:31'),
	(8, 'opmvek9jugte4m49km21sfnr02', 11, 1, '2025-01-14 07:39:18');

-- Listage de la structure de table webshop. categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `characteristics` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Listage des données de la table webshop.categories : ~5 rows (environ)
INSERT INTO `categories` (`id`, `name`, `characteristics`) VALUES
	(1, 'Électronique', '["Marque", "Couleur", "Garantie", "Stockage"]'),
	(2, 'Vêtements', '["Taille", "Couleur", "Matériau", "Style"]'),
	(3, 'Alimentation', '["Marque", "Poids", "Date d\'expiration", "Type"]'),
	(4, 'Sports', '["Type", "Niveau", "Matériau", "Taille"]'),
	(5, 'Livres', '["Genre", "Format", "Langue", "Année de publication"]');

-- Listage de la structure de table webshop. products
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `views` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- Listage des données de la table webshop.products : ~25 rows (environ)
INSERT INTO `products` (`id`, `name`, `description`, `image_url`, `category_id`, `date_added`, `views`) VALUES
	(1, 'iPhone 15 Pro', 'Smartphone haut de gamme avec appareil photo professionnel', 'images/iphone15.svg', 1, '2025-01-14 07:33:01', 245),
	(2, 'Samsung Galaxy S24', 'Android flagship avec écran AMOLED 6.8"', 'images/galaxy.svg', 1, '2025-01-14 07:33:01', 189),
	(3, 'MacBook Air M2', 'Ordinateur portable léger et puissant', 'images/macbook.svg', 1, '2025-01-14 07:33:01', 167),
	(4, 'Sony WH-1000XM5', 'Casque à réduction de bruit active', 'images/sony.svg', 1, '2025-01-14 07:33:01', 98),
	(5, 'iPad Air', 'Tablette polyvalente pour créatifs', 'images/ipad.svg', 1, '2025-01-14 07:33:01', 145),
	(6, 'T-shirt Basic', 'T-shirt 100% coton bio', 'images/tshirt.svg', 2, '2025-01-14 07:33:01', 78),
	(7, 'Jean Slim', 'Jean coupe slim en denim stretch', 'images/jeans.svg', 2, '2025-01-14 07:33:01', 92),
	(8, 'Veste Hiver', 'Veste chaude imperméable', 'images/jacket.svg', 2, '2025-01-14 07:33:01', 156),
	(9, 'Chaussures Running', 'Chaussures légères pour course', 'images/shoes.svg', 2, '2025-01-14 07:33:01', 134),
	(10, 'Pull Cachemire', 'Pull doux en cachemire pur', 'images/sweater.svg', 2, '2025-01-14 07:33:01', 67),
	(11, 'Chocolat Noir', 'Chocolat noir 70% cacao', 'images/chocolate.svg', 3, '2025-01-14 07:33:01', 45),
	(12, 'Café Arabica', 'Café en grains premium', 'images/coffee.svg', 3, '2025-01-14 07:33:01', 89),
	(13, 'Thé Vert Bio', 'Thé vert japonais bio', 'images/tea.svg', 3, '2025-01-14 07:33:01', 34),
	(14, 'Miel Local', 'Miel de fleurs local', 'images/honey.svg', 3, '2025-01-14 07:33:01', 56),
	(15, 'Huile d\'Olive', 'Huile d\'olive extra vierge', 'images/oil.svg', 3, '2025-01-14 07:33:01', 78),
	(16, 'Raquette Tennis', 'Raquette professionnelle', 'images/racket.svg', 4, '2025-01-14 07:33:01', 89),
	(17, 'Ballon Football', 'Ballon officiel compétition', 'images/ball.svg', 4, '2025-01-14 07:33:01', 67),
	(18, 'Tapis Yoga', 'Tapis antidérapant pro', 'images/yoga.svg', 4, '2025-01-14 07:33:01', 123),
	(19, 'Vélo Route', 'Vélo carbone ultraléger', 'images/bike.svg', 4, '2025-01-14 07:33:01', 234),
	(20, 'Skis All-Mountain', 'Skis polyvalents tous niveaux', 'images/ski.svg', 4, '2025-01-14 07:33:01', 178),
	(21, 'Le Petit Prince', 'Un classique intemporel', 'images/prince.svg', 5, '2025-01-14 07:33:01', 45),
	(22, '1984', 'Roman dystopique de George Orwell', 'images/1984.svg', 5, '2025-01-14 07:33:01', 67),
	(23, 'Apprendre Python', 'Guide complet pour débutants', 'images/python.svg', 5, '2025-01-14 07:33:01', 189),
	(24, 'Cuisine Facile', 'Recettes rapides et délicieuses', 'images/cooking.svg', 5, '2025-01-14 07:33:01', 78),
	(25, 'Histoire de l\'Art', 'Panorama complet de l\'art', 'images/art.svg', 5, '2025-01-14 07:33:01', 56);

-- Listage de la structure de table webshop. products2
CREATE TABLE IF NOT EXISTS `products2` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `views` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Listage des données de la table webshop.products2 : ~0 rows (environ)

-- Listage de la structure de table webshop. product_prices
CREATE TABLE IF NOT EXISTS `product_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `start_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_prices_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

-- Listage des données de la table webshop.product_prices : ~50 rows (environ)
INSERT INTO `product_prices` (`id`, `product_id`, `price`, `start_date`) VALUES
	(1, 1, 1299.99, '2024-12-01'),
	(2, 1, 1199.99, '2025-01-01'),
	(3, 2, 1199.99, '2024-12-01'),
	(4, 2, 1099.99, '2025-01-01'),
	(5, 3, 1499.99, '2024-12-01'),
	(6, 3, 1399.99, '2025-01-01'),
	(7, 4, 399.99, '2024-12-01'),
	(8, 4, 349.99, '2025-01-01'),
	(9, 5, 799.99, '2024-12-01'),
	(10, 5, 749.99, '2025-01-01'),
	(11, 6, 29.99, '2024-12-01'),
	(12, 6, 24.99, '2025-01-01'),
	(13, 7, 89.99, '2024-12-01'),
	(14, 7, 79.99, '2025-01-01'),
	(15, 8, 199.99, '2024-12-01'),
	(16, 8, 169.99, '2025-01-01'),
	(17, 9, 129.99, '2024-12-01'),
	(18, 9, 99.99, '2025-01-01'),
	(19, 10, 199.99, '2024-12-01'),
	(20, 10, 179.99, '2025-01-01'),
	(21, 11, 7.99, '2024-12-01'),
	(22, 11, 6.99, '2025-01-01'),
	(23, 12, 19.99, '2024-12-01'),
	(24, 12, 17.99, '2025-01-01'),
	(25, 13, 12.99, '2024-12-01'),
	(26, 13, 11.99, '2025-01-01'),
	(27, 14, 15.99, '2024-12-01'),
	(28, 14, 14.99, '2025-01-01'),
	(29, 15, 24.99, '2024-12-01'),
	(30, 15, 22.99, '2025-01-01'),
	(31, 16, 249.99, '2024-12-01'),
	(32, 16, 229.99, '2025-01-01'),
	(33, 17, 29.99, '2024-12-01'),
	(34, 17, 27.99, '2025-01-01'),
	(35, 18, 49.99, '2024-12-01'),
	(36, 18, 44.99, '2025-01-01'),
	(37, 19, 2499.99, '2024-12-01'),
	(38, 19, 2299.99, '2025-01-01'),
	(39, 20, 699.99, '2024-12-01'),
	(40, 20, 649.99, '2025-01-01'),
	(41, 21, 24.99, '2024-12-01'),
	(42, 21, 22.99, '2025-01-01'),
	(43, 22, 19.99, '2024-12-01'),
	(44, 22, 17.99, '2025-01-01'),
	(45, 23, 49.99, '2024-12-01'),
	(46, 23, 44.99, '2025-01-01'),
	(47, 24, 34.99, '2024-12-01'),
	(48, 24, 29.99, '2025-01-01'),
	(49, 25, 79.99, '2024-12-01'),
	(50, 25, 69.99, '2025-01-01');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
